<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RankAchivement extends Model
{
    protected $table = 'rank_achivement';
    protected $guarded = [];

}
