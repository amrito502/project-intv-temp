<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GenerationSetting extends Model
{
    protected $table = 'generation_settings';
    protected $guarded = [];

}
